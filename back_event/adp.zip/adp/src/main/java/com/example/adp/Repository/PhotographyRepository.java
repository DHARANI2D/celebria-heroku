package com.example.adp.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.adp.Model.Photography;

@Repository
public interface PhotographyRepository extends JpaRepository<Photography, Long> {

    List<Photography> findByUserId(Long userId);
}
