package com.example.adp.Repository;

public @interface EnableOpenApi {

}
